﻿using Microsoft.AspNetCore.Mvc;

namespace ExamenFinalDWES.Controllers
{
    public class UsuarioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
