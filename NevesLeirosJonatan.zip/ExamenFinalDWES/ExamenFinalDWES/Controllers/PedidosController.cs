﻿using Microsoft.AspNetCore.Mvc;

namespace ExamenFinalDWES.Controllers
{
    public class PedidosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
